
wget http://colorization.eecs.berkeley.edu/siggraph/models/model.caffemodel -O ./models/reference_model/model.caffemodel
wget http://colorization.eecs.berkeley.edu/siggraph/models/global_model.caffemodel -O ./models/global_model/global_model.caffemodel
wget http://colorization.eecs.berkeley.edu/siggraph/models/dummy.caffemodel -O ./models/global_model/dummy.caffemodel
